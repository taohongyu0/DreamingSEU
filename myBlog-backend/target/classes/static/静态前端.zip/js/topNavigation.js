document.querySelectorAll('.navbar a').forEach(link => {  //顶部悬浮导航栏
    link.addEventListener('click', function(event) {
        event.preventDefault(); // Prevent the default link behavior
        if(this.textContent==="主页"){
            localStorage.setItem("showWhat","all");
            window.location.href = 'blogPush.html';
        }
        else if(this.textContent==="退出登录"){
            backToLogin();
        }
        else if(this.textContent==="发表博文"){
            createArticle();
        }
        else if(this.textContent==="个人中心"){
            goToPersonalCenter();
        }
        //alert(`You clicked on ${this.textContent}`);
    });
});

function goToPersonalCenter(){
    window.location.href = 'personalCenter.html';
}

function createArticle(){
    window.location.href = 'createArticle.html';
}

function backToLogin() {
    window.location.href = 'login.html';
    const data = localStorage.getItem("token");
    fetch("http://localhost:8088/user/quit",{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: data
    })
        .then(response => {
            if (!response.ok) {
                alert("response-网络响应失败");
                throw new Error('网络响应失败');
            }
            return response.json();
        })
        .then(data => {
            if(data.code!==200){
                alert("退出失败");
            }
        })
        .catch(error => {
            //alert("error-请求失败");
            console.error('请求失败:', error);
        });
}